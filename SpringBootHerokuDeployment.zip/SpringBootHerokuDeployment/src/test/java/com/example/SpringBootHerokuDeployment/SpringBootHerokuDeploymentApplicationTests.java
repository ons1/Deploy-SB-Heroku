package com.example.SpringBootHerokuDeployment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHerokuDeploymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
